
package com.iceipt.hrms.controller;

import com.iceipt.hrms.dto.PayrollPreviewResponse;
import com.iceipt.hrms.dto.PayrollSummaryResponse;
import com.iceipt.hrms.service.PayrollService;

import lombok.RequiredArgsConstructor;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/payroll")
@RequiredArgsConstructor
public class PayrollController {

    private final PayrollService payrollService;

    @PostMapping("/preview")
    @PreAuthorize("hasRole('ADMIN')")
    public PayrollPreviewResponse preparePayrollPreview(
            @RequestParam
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate payrollMonth) {

        return payrollService.preparePayrollPreview(payrollMonth);
    }

    @PostMapping("/confirm/{confirmationId}")
    @PreAuthorize("hasRole('ADMIN')")
    public List<PayrollSummaryResponse> confirmPayroll(
            @PathVariable String confirmationId) {

        return payrollService.confirmPayroll(confirmationId);
    }

    @GetMapping("/summary")
    @PreAuthorize("hasRole('ADMIN')")
    public List<PayrollSummaryResponse> getPayrollSummary(
            @RequestParam
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate payrollMonth) {

        return payrollService.getPayrollSummary(payrollMonth);
    }

    @GetMapping("/my")
    @PreAuthorize("hasRole('EMPLOYEE')")
    public List<PayrollSummaryResponse> getMyPayrollSummary() {

        return payrollService.getMyPayrollSummary();
    }
}
