
package com.iceipt.hrms.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class LoginResponse {

    private String token;
    private String tokenType;
    private Long userId;
    private Long employeeId;
    private String email;
    private String role;
    private String employeeName;
}
