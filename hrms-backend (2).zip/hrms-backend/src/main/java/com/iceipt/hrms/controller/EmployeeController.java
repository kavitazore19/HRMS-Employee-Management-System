
package com.iceipt.hrms.controller;

import com.iceipt.hrms.dto.EmployeeRequest;
import com.iceipt.hrms.dto.EmployeeResponse;
import com.iceipt.hrms.service.EmployeeService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employees")
@PreAuthorize("hasRole('ADMIN')")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @PostMapping
    public ResponseEntity<EmployeeResponse> createEmployee(
            @Valid @RequestBody EmployeeRequest request) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(employeeService.createEmployee(request));
    }

    @PostMapping("/{id}/login")
    public ResponseEntity<String> createEmployeeLogin(
            @PathVariable Long id,
            @RequestBody Map<String, String> request) {

        String temporaryPassword = request.get("temporaryPassword");

        if (temporaryPassword == null || temporaryPassword.isBlank()) {
            return ResponseEntity.badRequest()
                    .body("Temporary password is required");
        }

        employeeService.createLoginForExistingEmployee(
                id, temporaryPassword);

        return ResponseEntity.ok("Employee login created successfully");
    }

    @GetMapping
    public ResponseEntity<List<EmployeeResponse>> getAllEmployees() {
        return ResponseEntity.ok(employeeService.getAllEmployees());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EmployeeResponse> getEmployeeById(
            @PathVariable Long id) {

        return ResponseEntity.ok(employeeService.getEmployeeById(id));
    }
}
