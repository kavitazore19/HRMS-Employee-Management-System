
package com.iceipt.hrms.dto;

import java.time.LocalDate;

import com.iceipt.hrms.entity.LeaveApplication.LeaveType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LeaveRequest {

    private Long employeeId;

    private LeaveType leaveType;

    private LocalDate startDate;

    private LocalDate endDate;

    private String reason;
}
