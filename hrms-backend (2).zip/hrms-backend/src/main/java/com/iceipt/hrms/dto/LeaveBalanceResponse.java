
package com.iceipt.hrms.dto;

import com.iceipt.hrms.entity.LeaveApplication.LeaveType;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class LeaveBalanceResponse {

    private Long id;

    private Long employeeId;

    private LeaveType leaveType;

    private Integer totalDays;

    private Integer usedDays;

    private Integer remainingDays;
}
