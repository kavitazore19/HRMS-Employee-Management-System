
package com.iceipt.hrms.controller;

import java.util.List;

import com.iceipt.hrms.dto.AttendanceResponse;
import com.iceipt.hrms.service.AttendanceService;

import lombok.RequiredArgsConstructor;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/attendance")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN', 'EMPLOYEE')")
public class AttendanceController {

    private final AttendanceService attendanceService;

    @PostMapping("/punch-in/{employeeId}")
    public AttendanceResponse punchIn(
            @PathVariable Long employeeId) {
        return attendanceService.punchIn(employeeId);
    }

    @PostMapping("/punch-out/{employeeId}")
    public AttendanceResponse punchOut(
            @PathVariable Long employeeId) {
        return attendanceService.punchOut(employeeId);
    }

    @GetMapping("/today/{employeeId}")
    public AttendanceResponse getTodayAttendance(
            @PathVariable Long employeeId) {
        return attendanceService.getTodayAttendance(employeeId);
    }

    @GetMapping("/monthly/{employeeId}")
    public List<AttendanceResponse> getMonthlyAttendance(
            @PathVariable Long employeeId,
            @RequestParam int year,
            @RequestParam int month) {

        return attendanceService.getMonthlyAttendance(
                employeeId, year, month
        );
    }
}
