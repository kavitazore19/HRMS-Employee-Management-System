
package com.iceipt.hrms.controller;

import com.iceipt.hrms.dto.AuditLogResponse;
import com.iceipt.hrms.service.AuditLogService;

import lombok.RequiredArgsConstructor;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/audit-logs")
@RequiredArgsConstructor
public class AuditLogController {

    private final AuditLogService auditLogService;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public List<AuditLogResponse> getAllLogs() {
        return auditLogService.getAllLogs();
    }
}
