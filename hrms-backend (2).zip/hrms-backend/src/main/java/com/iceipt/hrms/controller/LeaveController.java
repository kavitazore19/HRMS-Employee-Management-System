
package com.iceipt.hrms.controller;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.iceipt.hrms.dto.LeaveRequest;
import com.iceipt.hrms.dto.LeaveResponse;
import com.iceipt.hrms.dto.LeaveBalanceResponse;
import com.iceipt.hrms.service.LeaveService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/leaves")
@RequiredArgsConstructor
public class LeaveController {

    private final LeaveService leaveService;

    // Employee applies for leave
    @PostMapping("/apply")
    @PreAuthorize("hasRole('EMPLOYEE')")
    public LeaveResponse applyLeave(@RequestBody LeaveRequest request) {
        return leaveService.applyLeave(request);
    }

    // Employee views own leave applications
    @GetMapping("/my")
    @PreAuthorize("hasRole('EMPLOYEE')")
    public List<LeaveResponse> getMyLeaves() {
        return leaveService.getMyLeaves();
    }

    // Employee checks own leave balances
    @GetMapping("/balances")
    @PreAuthorize("hasRole('EMPLOYEE')")
    public List<LeaveBalanceResponse> getMyLeaveBalances() {
        return leaveService.getMyLeaveBalances();
    }

    // Admin views pending applications
    @GetMapping("/pending")
    @PreAuthorize("hasRole('ADMIN')")
    public List<LeaveResponse> getPendingLeaves() {
        return leaveService.getPendingLeaves();
    }

    // Admin approves leave
    @PutMapping("/{leaveId}/approve")
    @PreAuthorize("hasRole('ADMIN')")
    public LeaveResponse approveLeave(@PathVariable Long leaveId) {
        return leaveService.reviewLeave(leaveId, true);
    }

    // Admin rejects leave
    @PutMapping("/{leaveId}/reject")
    @PreAuthorize("hasRole('ADMIN')")
    public LeaveResponse rejectLeave(@PathVariable Long leaveId) {
        return leaveService.reviewLeave(leaveId, false);
    }
}
