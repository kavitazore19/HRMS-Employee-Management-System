
package com.iceipt.hrms.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.AllArgsConstructor;

@Getter
@AllArgsConstructor
public class AttendanceResponse {

    private Long id;
    private Long employeeId;
    private LocalDate attendanceDate;
    private LocalDateTime punchIn;
    private LocalDateTime punchOut;
    private String status;
}
