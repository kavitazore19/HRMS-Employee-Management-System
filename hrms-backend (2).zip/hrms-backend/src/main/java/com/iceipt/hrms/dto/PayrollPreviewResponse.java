package com.iceipt.hrms.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@AllArgsConstructor
public class PayrollPreviewResponse {

    private String confirmationId;
    private LocalDate payrollMonth;
    private LocalDateTime expiresAt;
    private List<EmployeePayrollPreview> employees;

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class EmployeePayrollPreview {

        private Long employeeId;
        private String employeeName;
        private BigDecimal basicSalary;
        private BigDecimal allowances;
        private BigDecimal deductions;
        private BigDecimal payableSalary;
        private int presentDays;
        private int absentDays;
    }
}