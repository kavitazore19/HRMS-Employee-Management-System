
package com.iceipt.hrms.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.iceipt.hrms.entity.LeaveApplication.LeaveStatus;
import com.iceipt.hrms.entity.LeaveApplication.LeaveType;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class LeaveResponse {

    private Long id;

    private Long employeeId;

    private LeaveType leaveType;

    private LocalDate startDate;

    private LocalDate endDate;

    private Integer totalDays;

    private String reason;

    private LeaveStatus status;

    private LocalDateTime createdAt;
}
