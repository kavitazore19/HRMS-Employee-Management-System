package com.iceipt.hrms.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@AllArgsConstructor
public class PayrollSummaryResponse {

    private Long payrollId;
    private Long employeeId;
    private String employeeName;
    private LocalDate payrollMonth;
    private BigDecimal basicSalary;
    private BigDecimal allowances;
    private BigDecimal deductions;
    private BigDecimal payableSalary;
    private int presentDays;
    private int absentDays;
    private String status;
}