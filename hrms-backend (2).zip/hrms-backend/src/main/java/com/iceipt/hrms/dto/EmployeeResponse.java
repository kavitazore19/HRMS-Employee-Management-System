
package com.iceipt.hrms.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@AllArgsConstructor
public class EmployeeResponse {

    private Long id;
    private String employeeCode;
    private String fullName;
    private String email;
    private String department;
    private String designation;
    private LocalDate joiningDate;
    private BigDecimal salary;
    private Boolean active;
}
